This folder contains sample data files used in Fabric Dev Camp.

More info at https://github.com/FabricDevCamp/SampleData